const nodemailer = require("nodemailer");

async function sendEmail(){
    let tp = nodemailer.createTransport({
        service: "Gmail",
        auth: {
            user: "MerlotClientNotifcation@gmail.com",
            pass: "oQCpfUuLpPZh3rPhjRpj"
        }
    });

    let mail = {
        from: '"MerlotNoReply" <MerlotClientNotifcation@gmail.coma>',
        to: "u16009917@tuks.co.za, u16099860@tuks.co.za, u17035989@tuks.co.za, u13286383@tuks.co.za, u15048030@tuks.co.za, u16313382@tuks.co.za",
        subject: "Notification",
        html: "<span>Hey Guys good news we can send emails now ^^</span>"
    };

    let info = await tp.sendMail(mail);

    console.log("Message sent: %s", info.messageId);
};

sendEmail().catch(console.error);